export REDIS_PASSWORD=password123 $ docker run -d --name redis -p 6379:6379 -e REDIS_PASSWORD=password123 bitnami/redis:latest
go mod init github.com/MagalixCorp/sample-api
go build
